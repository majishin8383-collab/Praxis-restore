import { initRouter } from "./router.js";

initRouter();
